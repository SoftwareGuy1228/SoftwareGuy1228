import tkinter
import tkinter as tk
import random
from tkinter import *
from tkinter import filedialog, Text
import os
from PIL import ImageTk, Image
import smtplib


# Please do not use the name funnys_testing_1472 unless you are testing. All messages with that name will not count and be deleted!
email = os.environ.get('EMAIL')
epassword1 = os.environ.get('PASSWORD')
password2 = os.environ.get('adminpassword')
send = True

root = tk.Tk()
root.config(bg='#800000', height=70, width=350)
show = True
myText = tk.Text(root, height=1, width=35)
myText.pack()
permLabel1 = tk.Label(root, text="^", bg="#800000")
permLabel1.pack()
permLabel2 = tk.Label(root, text="Full Name", bg="#800000")
permLabel2.pack()
bgimage = ImageTk.PhotoImage(Image.open('potato.jpg'))


def func():

    fh = open('cards.txt', 'a')
    number = random.randint(1111111, 9999999)
    writing = myText.get("1.0", END)
    print(writing)

    final = "code: " + str(number) + " Name: " + writing

    label = tk.Label(root, text=final + "Please Copy Your 7 Digit Code", bg="#800000")
    label.pack()

    if send:
        with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.ehlo()
            smtp.login(email, epassword1)
            subject2 = str(final)
            body2 = str(final)
            msg2 = f'Subject: {subject2},/n/n{body2}'
            smtp.sendmail(email, email, msg2)




root.title('Preorder an item')

lab = Label(root, height=250, width=250, bg="#800000", image=bgimage)
lab.pack()
warning = tk.Label(root, text='WARNING, All Preordered Items Will Be 20% More Expensive Than Normal', bg="#800000")
warning.pack()
PurchaseItem = tk.Button(root, text="Buy Item", padx=10, pady=5, fg="#0000FF", bg="white", command=func)

PurchaseItem.pack()

root.mainloop()
